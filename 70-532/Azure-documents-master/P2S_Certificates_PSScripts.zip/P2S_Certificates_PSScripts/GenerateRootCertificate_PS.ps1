﻿#--------------- fOR ROOT CERTIFICATES ---------------
#Create and install the root certificate
$cert = New-SelfSignedCertificate -Type Custom `
                -KeySpec Signature `
                -Subject "CN=P2SRootCert" `
                -KeyExportPolicy Exportable `
                -HashAlgorithm sha256 `
                -KeyLength 2048 `
                -CertStoreLocation "Cert:\CurrentUser\My" `
                -KeyUsageProperty Sign `
                -KeyUsage CertSign

#--------------- FOR CLIENT CERTIFICATES -------------
#List the installed certificates and its thumbprints
Get-ChildItem -Path “Cert:\CurrentUser\My”

#Get the certificate reference using the thumbprint
#$cert = Get-ChildItem -Path "Cert:\CurrentUser\My\<Cert thumbprint value>"
$cert = Get-ChildItem -Path "Cert:\CurrentUser\My\778510D64B4C5F36B63DF55341BC754B17518C03"

#Create and Install a child certificate 
New-SelfSignedCertificate -Type Custom `
            -KeySpec Signature `
            -Subject "CN=P2SChildCert" `
            -KeyExportPolicy Exportable `
            -HashAlgorithm sha256 `
            -KeyLength 2048 `
            -CertStoreLocation "Cert:\CurrentUser\My" `
            -Signer $cert `
            -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.2")