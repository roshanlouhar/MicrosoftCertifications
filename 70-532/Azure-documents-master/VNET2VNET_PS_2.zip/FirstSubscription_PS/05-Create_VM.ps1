﻿
#create a new VM in FrontEnd subnet of FirstVNET
$locationName ="Southeast Asia"
$resourceGroupName="HybridCloudResourceGroup1"

#create storage account
$storageAccName = "firstvnetvmstorage"
$storageAcc = New-AzureRmStorageAccount -ResourceGroupName $resourceGroupName `
                        -Name $storageAccName `
                        -Type "Standard_LRS" `
                        -Location $locationName

#Get the FrontEnd subnet from FirstVNET
$subnetName = "FrontEnd"
$VNETName="FirstVNET"

$VNET=Get-AzureRmVirtualNetwork -Name $VNETName -ResourceGroupName $resourceGroupName
$frontEndSubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $VNET

#create public IP address and network interface
$webServerPublicIPName = "WebServerPublicIP"
$webServerPublicIP = New-AzureRmPublicIpAddress -Name $webServerPublicIPName `
            -ResourceGroupName $resourceGroupName `
            -Location $locationName `
            -AllocationMethod Dynamic

$nicName = "WebServerNIC"
$nic = New-AzureRmNetworkInterface -Name $nicName `
            -ResourceGroupName $resourceGroupName `
            -Location $locationName `
            -SubnetId $frontEndSubnet.Id `
            -PublicIpAddressId $webServerPublicIP.Id

#Create a virtual machine
#Run the command to set the administrator account name and password for the virtual machine.
$cred = Get-Credential -Message "Type the name and password of the local administrator account."
$vmName = "WebServerVM"
$vm = New-AzureRmVMConfig -VMName $vmName `
            -VMSize "Standard_A1"

#run the commands to define the operating system to use.
$compName = "MSVM-COMPUTER"
$vm = Set-AzureRmVMOperatingSystem -VM $vm `
            -Windows -ComputerName $compName `
            -Credential $cred `
            -ProvisionVMAgent -EnableAutoUpdate

#Run the command to define the image to use to provision the virtual machine.
$vm = Set-AzureRmVMSourceImage -VM $vm `
            -PublisherName MicrosoftWindowsServer `
            -Offer WindowsServer `
            -Skus 2012-R2-Datacenter `
            -Version "latest"

#add the network interface created to the virtual machine configuration.
$vm = Add-AzureRmVMNetworkInterface -VM $vm `
            -Id $nic.Id

$blobPath = "vhds/WindowsR2DC.vhd"
$osDiskUri = $storageAcc.PrimaryEndpoints.Blob.ToString() + $blobPath

$diskName = "windowsvmosdisk"
$vm = Set-AzureRmVMOSDisk -VM $vm `
            -Name $diskName `
            -VhdUri $osDiskUri `
            -CreateOption fromImage

New-AzureRmVM -ResourceGroupName $resourceGroupName `
            -Location $locationName `
            -VM $vm