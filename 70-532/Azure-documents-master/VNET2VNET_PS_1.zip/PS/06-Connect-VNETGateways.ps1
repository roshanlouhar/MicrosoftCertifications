﻿Login-AzureRmAccount
#Create connection between two gateways

$resourceGroupName="HybridCloudResGroup"
$fnGatewayName="FirstVNETGateway"
$secGatewayName="SecondVNETGateway"
$firstVNETLocation="Southeast Asia"
$secondVNETLocation="East US"
$fnToSec="FirstVNETtoSecondVNET"
$secToFn="SecondVNETtoFirstVNET"

#Get the gateways references
$fnVNETGateway = Get-AzureRmVirtualNetworkGateway -Name $fnGatewayName -ResourceGroupName $resourceGroupName
$secVNETGateway = Get-AzureRmVirtualNetworkGateway -Name $secGatewayName -ResourceGroupName $resourceGroupName

#Connecting FirstVNET to SecondVNET

New-AzureRmVirtualNetworkGatewayConnection -Name $fnToSec `
                            -ResourceGroupName $resourceGroupName `
                            -VirtualNetworkGateway1 $fnVNETGateway `
                            -VirtualNetworkGateway2 $secVNETGateway `
                            -Location $firstVNETLocation `
                            -ConnectionType Vnet2Vnet `
                            -SharedKey 'sample1234'


New-AzureRmVirtualNetworkGatewayConnection -Name $secToFn `
                            -ResourceGroupName $resourceGroupName `
                            -VirtualNetworkGateway1 $secVNETGateway `
                            -VirtualNetworkGateway2 $fnVNETGateway `
                            -Location $secondVNETLocation `
                            -ConnectionType Vnet2Vnet `
                            -SharedKey 'sample1234'