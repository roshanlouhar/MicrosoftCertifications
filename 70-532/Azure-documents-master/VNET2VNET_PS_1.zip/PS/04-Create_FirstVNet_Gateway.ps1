﻿
#Create a Public IP for Virtual Network Gateway of FirstVNET
$resourceGroupName="HybridCloudResGroup"
$firstVNETName="FirstVNET"
$firstVNETLocation="Southeast Asia"

$fnGatewayPublicIPName="FirstGatewayPublicIP"
$fnGatewayIPConfigName="FirstGatewayIPConfig"
$fnGatewayName="FirstVNETGateway"

$fnGatewayPublicIP = New-AzureRmPublicIpAddress -Name $fnGatewayPublicIPName `
                                    -ResourceGroupName $resourceGroupName `
                                    -Location $firstVNETLocation `
                                    -AllocationMethod Dynamic

$firstVNET = Get-AzureRmVirtualNetwork -Name $firstVNETName `
                        -ResourceGroupName $resourceGroupName

$fnGatewaySubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $fnGatewaySubnetName -VirtualNetwork $firstVNET

$fnGatewayIPConfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name $fnGatewayIPConfigName -Subnet $fnGatewaySubnet -PublicIpAddress $fnGatewayPublicIP

New-AzureRmVirtualNetworkGateway -Name $fnGatewayName -ResourceGroupName $resourceGroupName `
                                -Location $firstVNETLocation -IpConfigurations $fnGatewayIPConfig -GatewayType Vpn `
                                -VpnType RouteBased -GatewaySku Standard