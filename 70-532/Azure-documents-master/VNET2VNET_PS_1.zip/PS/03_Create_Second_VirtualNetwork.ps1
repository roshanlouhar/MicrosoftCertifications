﻿#SecondVNET creation 
$resourceGroupName="HybridCloudResGroup"
$secondVNETName="SecondVNET"
$secondVNETLocation="East US"
$secondVNETAddressSpace="10.50.0.0/16"
$devSubnetName ="Dev"
$testSubnetName = "Test"
$secGatewaySubnetName="GatewaySubnet"
$devSubnetIPrange ="10.50.1.0/24"
$testSubnetIPrange ="10.50.2.0/24"
$secGatewaySubnetIPrange ="10.50.3.0/27"

#Create Subnet configurations for SecondVNET
$devSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $devSubnetName -AddressPrefix $devSubnetIPrange
$testSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $testSubnetName -AddressPrefix $testSubnetIPrange
$secondVNETGatewaySubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $secGatewaySubnetName -AddressPrefix $secGatewaySubnetIPrange

#Create SecondVNET
New-AzureRmVirtualNetwork -Name $secondVNETName `
                -ResourceGroupName $resourceGroup `
                -Location $secondVNETLocation `
                -AddressPrefix $secondVNETAddressSpace `
                -Subnet $devSubnet,$testSubnet,$secondVNETGatewaySubnet