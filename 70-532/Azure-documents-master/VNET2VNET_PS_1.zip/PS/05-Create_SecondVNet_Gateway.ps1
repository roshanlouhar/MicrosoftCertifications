﻿
#Create a Public IP for Virtual Network Gateway of SecondVNET
$resourceGroupName="HybridCloudResGroup"
$secondVNETName="SecondVNET"
$secondVNETLocation="East US"
$secGatewaySubnetName="GatewaySubnet"

$secGatewayPublicIPName="SecondGatewayPublicIP"
$secGatewayIPConfigName="SecondGatewayIPConfig"
$secGatewayName="SecondVNETGateway"

$secGatewayPublicIP = New-AzureRmPublicIpAddress -Name $secGatewayPublicIPName `
                                    -ResourceGroupName $resourceGroupName `
                                    -Location $secondVNETLocation `
                                    -AllocationMethod Dynamic

$secondVNET = Get-AzureRmVirtualNetwork -Name $secondVNETName `
                        -ResourceGroupName $resourceGroupName

$secGatewaySubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $secGatewaySubnetName -VirtualNetwork $secondVNET


$secGatewayIPConfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name $secGatewayIPConfigName -Subnet $secGatewaySubnet -PublicIpAddress $secGatewayPublicIP

New-AzureRmVirtualNetworkGateway -Name $secGatewayName -ResourceGroupName $resourceGroupName `
                                -Location $secondVNETLocation -IpConfigurations $secGatewayIPConfig -GatewayType Vpn `
                                -VpnType RouteBased -GatewaySku Standard